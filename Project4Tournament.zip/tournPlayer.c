#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "tournPlayer.h"
#include "battleship.h"

#define HORIZ 0
#define VERT 1

#define RAND 2
#define TARGET 3

#define UP 4
#define DOWN 5
#define LEFT 6
#define RIGHT 7

void usageExit()
{
   fprintf(stderr, "Usage: player readFD writeFD\n");
   exit(EXIT_FAILURE);
}
void checkArgs(int *readFD, int *writeFD, int argNum, char *args[])
{
   if(argNum != 3)
      usageExit();
   else
   {
      if(sscanf(args[1], "%d", readFD) != 1 || 
         sscanf(args[2], "%d", writeFD) != 1)
         usageExit();
   }
}
int hasShip(int startRow, int startCol, int size, int direc, 
   char board[SIZE][SIZE])
{
   int i;
   if(direc == HORIZ)
   {
      for(i = 0; i < size; i++)
      {
         if(board[startRow][startCol+i] != OPEN_WATER)
            return 1;
      }
   }
   else if(direc == VERT)
   {
      for(i = 0; i < size; i++)
      {
         if(board[startRow+i][startCol] != OPEN_WATER)
            return 1;
      }
   }
   return 0;
}
void placePB(char board[SIZE][SIZE])
{
   int startRow, startCol, i, direc;
   direc = rand() % 2;
   if(direc == HORIZ)
   {
      startRow = rand() % 10;
      startCol = rand() % 9;
      if(!hasShip(startRow, startCol, SIZE_PATROL_BOAT, direc, board))
      {
         for(i = 0; i < SIZE_PATROL_BOAT; i++)
            board[startRow][startCol+i] = PATROL_BOAT;
      }
      else
         placePB(board);
   }
   else if(direc == VERT)
   {
      startRow = rand() % 9;
      startCol = rand() % 10;
      if(!hasShip(startRow, startCol, SIZE_PATROL_BOAT, direc, board))
      {
         for(i = 0; i < SIZE_PATROL_BOAT; i++)
            board[startRow+i][startCol] = PATROL_BOAT;
      }
      else
         placePB(board);
   }
}
void placeSub(char board[SIZE][SIZE])
{
   int startRow, startCol, i, direc;
   direc = rand() % 2;
   if(direc == HORIZ)
   {
      startRow = rand() % 10;
      startCol = rand() % 8;
      if(!hasShip(startRow, startCol, SIZE_SUBMARINE, direc, board))
      {
         for(i = 0; i < SIZE_SUBMARINE; i++)
            board[startRow][startCol+i] = SUBMARINE;
      }
      else
         placeSub(board);
   }
   else if(direc == VERT)
   {
      startRow = rand() % 8;
      startCol = rand() % 10;
      if(!hasShip(startRow, startCol, SIZE_SUBMARINE, direc, board))
      {
         for(i = 0; i < SIZE_SUBMARINE; i++)
            board[startRow+i][startCol] = SUBMARINE;
      }
      else
         placeSub(board);
   }
}
void placeDes(char board[SIZE][SIZE])
{
   int startRow, startCol, i, direc;
   direc = rand() % 2;
   if(direc == HORIZ)
   {
      startRow = rand() % 10;
      startCol = rand() % 8;
      if(!hasShip(startRow, startCol, SIZE_DESTROYER, direc, board))
      {
         for(i = 0; i < SIZE_DESTROYER; i++)
            board[startRow][startCol+i] = DESTROYER;
      }
      else
         placeDes(board);
   }
   else if(direc == VERT)
   {
      startRow = rand() % 8;
      startCol = rand() % 10;
      if(!hasShip(startRow, startCol, SIZE_DESTROYER, direc, board))
      {
         for(i = 0; i < SIZE_DESTROYER; i++)
            board[startRow+i][startCol] = DESTROYER;
      }
      else
         placeDes(board);
   }
}
void placeBatt(char board[SIZE][SIZE])
{
   int startRow, startCol, i, direc;
   direc = rand() % 2;
   if(direc == HORIZ)
   {
      startRow = rand() % 10;
      startCol = rand() % 7;
      if(!hasShip(startRow, startCol, SIZE_BATTLESHIP, direc, board))
      {
         for(i = 0; i < SIZE_BATTLESHIP; i++)
            board[startRow][startCol+i] = BATTLESHIP;
      }
      else
         placeBatt(board);
   }
   else if(direc == VERT)
   {
      startRow = rand() % 7;
      startCol = rand() % 10;
      if(!hasShip(startRow, startCol, SIZE_BATTLESHIP, direc, board))
      {
         for(i = 0; i < SIZE_BATTLESHIP; i++)
            board[startRow+i][startCol] = BATTLESHIP;
      }
      else
         placeBatt(board);
   }
}
void placeAC(char board[SIZE][SIZE])
{
   int startRow, startCol, i, direc;
   direc = rand() % 2;
   if(direc == HORIZ)
   {
      startRow = rand() % 10;
      startCol = rand() % 6;
      if(!hasShip(startRow, startCol, SIZE_AIRCRAFT_CARRIER, direc, board))
      {
         for(i = 0; i < SIZE_AIRCRAFT_CARRIER; i++)
            board[startRow][startCol+i] = AIRCRAFT_CARRIER;
      }
      else
         placeAC(board);
   }
   else if(direc == VERT)
   {
      startRow = rand() % 6;
      startCol = rand() % 10;
      if(!hasShip(startRow, startCol, SIZE_AIRCRAFT_CARRIER, direc, board))
      {
         for(i = 0; i < SIZE_AIRCRAFT_CARRIER; i++)
            board[startRow+i][startCol] = AIRCRAFT_CARRIER;
      }
      else
         placeAC(board);
   }
}
void buildGame(char board[SIZE][SIZE], int writeFD)
{
   int i, j;
   for(i = 0; i < SIZE; i++)
   {
      for(j = 0; j < SIZE; j++)
         board[i][j] = OPEN_WATER;
   }
   placePB(board);
   placeSub(board);
   placeDes(board);
   placeBatt(board);
   placeAC(board);
   write(writeFD, board, SIZE*SIZE);
}
int hasCellsLeft(Cell *toShoot[50])
{
   int i;
   for(i = 0; i < 50; i++)
   {
      if(toShoot[i]->beenShot == 0)
         return 1;
   }
   return 0;
}
void shootRemain(Shot *currShot, int writeFD, int checker[SIZE][SIZE])
{
   int i, j;
   for(i = 0;i<SIZE;i++)
   {
      for(j=0;j<SIZE;j++)
      {
         if(checker[i][j] == 2)
         {
            currShot->row = i;
            currShot->col = j;
            checker[i][j] = 1;
            write(writeFD, currShot, sizeof(*currShot));
            return;
         }
      }
   }
}
void sendRandShot(Shot *currShot, int writeFD, Cell *toShoot[50], 
   int checker[SIZE][SIZE])
{
   int index = rand() % 50;
   if(toShoot[index]->beenShot == 0)
   {
      currShot->row = toShoot[index]->row;
      currShot->col = toShoot[index]->col;
      toShoot[index]->beenShot = 1;
      checker[toShoot[index]->row][toShoot[index]->col] = 1;
      write(writeFD, currShot, sizeof(*currShot));
   }
   else if(hasCellsLeft(toShoot) == 1)
      sendRandShot(currShot, writeFD, toShoot, checker);
   else
      shootRemain(currShot, writeFD, checker);
}
void setBeenShot(int row, int col, Cell *toShoot[50])
{
   int i;
   for(i = 0; i < 50; i++)
   {
      if(toShoot[i]->row == row && toShoot[i]->col == col)
      {
         toShoot[i]->beenShot = 1;
         break;
      }
   }
}
int targetShip(Shot *currShot, int writeFD, Cell *toShoot[50], 
   int checker[SIZE][SIZE], int *direc)
{
   int lastRow = currShot->row, lastCol = currShot->col;

   if(*direc == UP)
   {
      if(lastRow != 0)
      {
         (currShot->row)--;
         if(checker[currShot->row][currShot->col] != 1)
         {
            checker[currShot->row][currShot->col] = 1;
            setBeenShot(currShot->row, currShot->col, (Cell **)toShoot);
            write(writeFD, currShot, sizeof(*currShot));
            return 0;
         }
         else
            return 1;
      }
      else
         return 1;
   }
   if(*direc == DOWN)
   {
      if(lastRow != 9)
      {
         (currShot->row)++;
         if(checker[currShot->row][currShot->col] != 1)
         {
            checker[currShot->row][currShot->col] = 1;
            setBeenShot(currShot->row, currShot->col, (Cell **)toShoot);
            write(writeFD, currShot, sizeof(*currShot));
            return 0;
         }
         else
            return 1;
      }
      else
         return 1;
   }
   if(*direc == LEFT)
   {
      if(lastCol != 0)
      {
         (currShot->col)--;
         if(checker[currShot->row][currShot->col] != 1)
         {
            checker[currShot->row][currShot->col] = 1;
            setBeenShot(currShot->row, currShot->col, (Cell **)toShoot);
            write(writeFD, currShot, sizeof(*currShot));
            return 0;
         }
         else
            return 1;
      }
      else
         return 1;
   }
   if(*direc == RIGHT)
   {
      if(lastCol != 9)
      {
         (currShot->col)++;
         if(checker[currShot->row][currShot->col] != 1)
         {
            checker[currShot->row][currShot->col] = 1;
            setBeenShot(currShot->row, currShot->col, (Cell **)toShoot);
            write(writeFD, currShot, sizeof(*currShot));
            return 0;
         }
         else
            return 1;
      }
      else
         return 1;
   }
   return 0;
}
void fillCheckArray(int checker[SIZE][SIZE])
{
   int i, j;
   for(i = 0; i < SIZE; i++)
   {
      for(j = 0; j < SIZE; j++)
         checker[i][j] = -1;
   }
}
void fillCellArray(Cell *toShoot[50])
{
   int i, currRow = 0, currCol = 0;
   for(i = 0; i < 50; i++)
   {
      toShoot[i] = malloc(sizeof(Cell));
      toShoot[i]->beenShot = 0;
      toShoot[i]->row = currRow;
      toShoot[i]->col = currCol;
      currCol = currCol + 2;
      if(currCol > 9)
      {
         currRow++;
         if(currRow % 2 == 0)
            currCol = 0;
         else
            currCol = 1;
      }
   }
}
void freeCellArray(Cell *toShoot[50])
{
   int i;
   for(i = 0;i<50;i++)
      free(toShoot[i]);
}
void setAdj(Shot *currShot, int checker[SIZE][SIZE])
{
   if(currShot->row != 0)
   {
      if(checker[currShot->row-1][currShot->col] == -1)
         checker[currShot->row-1][currShot->col] = 2;
   }
   if(currShot->row != 9)
   {
      if(checker[currShot->row+1][currShot->col] == -1)
         checker[currShot->row+1][currShot->col] = 2;
   }
   if(currShot->col != 0)
   {
      if(checker[currShot->row][currShot->col-1] == -1)
         checker[currShot->row][currShot->col-1] = 2;
   }
   if(currShot->col != 9)
   {
      if(checker[currShot->row][currShot->col+1] == -1)
         checker[currShot->row][currShot->col+1] = 2;
   }
}
int main(int argc, char *argv[])
{
   int nextMove, readFD, writeFD, res, shotRes, firstHitRow, 
      firstHitCol, direc = UP, mode = RAND, checker[SIZE][SIZE];
   char board[SIZE][SIZE];
   Shot currShot, oppShot;
   Cell toShoot[50];
   if(toShoot == NULL)
   {
      perror(NULL);
      exit(EXIT_FAILURE);
   }
   fillCheckArray(checker);
   fillCellArray((Cell **)&toShoot);
   checkArgs(&readFD, &writeFD, argc, argv);
   while(1)
   {
      res = read(readFD, &nextMove, sizeof(nextMove));
      if(res == 0)
         break;
      if(nextMove == NEW_GAME)
      {
         mode = RAND;
         freeCellArray((Cell **)&toShoot);
         fillCheckArray(checker);
         fillCellArray((Cell **)&toShoot);
         buildGame(board, writeFD);
      }
      else if(nextMove == SHOT_REQUEST)
      {
         if(mode == RAND)
            sendRandShot(&currShot, writeFD, (Cell **)&toShoot, checker);
         else if(mode == TARGET)
         {
            if(direc > RIGHT)
               direc = UP;
            while(targetShip(&currShot, writeFD, 
               (Cell **)&toShoot, checker, &direc) != 0)
            {
               currShot.row = firstHitRow;
               currShot.col = firstHitCol;
               direc++;
               if(direc > RIGHT)
               {
                  if(hasCellsLeft((Cell **)&toShoot) == 1)
                     sendRandShot(&currShot, writeFD, 
                        (Cell **)&toShoot, checker);
                  else
                     shootRemain(&currShot, writeFD, checker);
               }
            }
         }
      }
      else if(nextMove == SHOT_RESULT)
      {
         res = read(readFD, &shotRes, sizeof(shotRes));
         if(shotRes == HIT)
         {
            setAdj(&currShot, checker);
            if(mode == RAND)
            {
               firstHitRow = currShot.row;
               firstHitCol = currShot.col;
               mode = TARGET;
               direc = UP;
            }
         }
         else if(shotRes == SINK)
         {
            setAdj(&currShot, checker);
            mode = RAND;
         }
         else if(shotRes == MISS)
         {
            if(mode == TARGET)
            {
               currShot.row = firstHitRow;
               currShot.col = firstHitCol;
               direc++;
            }
         }
      }
      else if(nextMove == OPPONENTS_SHOT)
         res = read(readFD, &oppShot, sizeof(oppShot));
   }
   return EXIT_SUCCESS;
}